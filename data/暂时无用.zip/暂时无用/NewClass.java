/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package 暂时无用;

/**
 *
 * @author WWW
 */
public class NewClass {

    public static void main(String[] args) {
        double m = Math.log(0.3);
        double n = 0.0349 - m;
        double y = n / 0.9631;

        System.out.println(Math.pow(y, 1 / 0.67));

        double a = 3.14 * (0.1 * 0.1 - 0.05 * 0.05) / 4.0;
        System.out.println(a*1.4561862310422198*86400);

    }
}
